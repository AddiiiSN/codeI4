<?php

namespace App\Models;

use CodeIgniter\Model;

class ReportModel extends Model
{
    protected $table = 'report';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $allowedFields = ['idPasien','nama', 'usia', 'alamat', 'no.hp', 'jenisPelayanan','jenisKelamin'];
}