<?php echo $this->include('template/header'); ?>
<main id="main" class="main">
    <div class="container mb-5"
        <div class="judul">
            <h2 class="text-center">Tambah Jenis Pelayanan</h2>
        </div>
    </div>
<form action="" method="post" id="text-editor">
    <div class="form-group">
        <label for="jenis">Jenis Pelayanan</label>
        <input type="text" name="title" class="form-control" placeholder="Jenis Pelayanan Klinik" required>
    </div>
        <div class="form-group">
        <label for="dokter">Nama Dokter</label>
        <input type="text" name="dokter" class="form-control" placeholder="dr. Adi Setiawan" required>
    </div>
    <div class="form-group">
        <label for="idDokter">ID Dokter</label>
        <input type="text" name="idDokter" class="form-control" placeholder="312110333" required>
    </div>
    <div class="form-group">
        <label for="jamPraktek">Jam Praktek</label>
        <input type="text" name="jamPraktek" class="form-control" placeholder="08.00 - 17.00 WIB" required>
    </div>    
    <div class="form-group">
        <button type="submit" name="status" value="published" class="btn btn-primary">Publish</button>
    </div>
</form>
</main>
<?php echo $this->include('template/footer'); ?>