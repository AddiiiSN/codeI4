<!DOCTYPE html>
<html lang="en">

<head>
    <title>Welcome | Pemrograman Web II</title>
    <!-- Vendor CSS Files -->
    <link href="assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

 <link rel="stylesheet" href="<?php echo base_url('css/style.css'); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">


    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>
    <header id="header" class="header fixed-top align-items-center d-flex">
        <div class="d-flex align-items-center justify-content-between">
            <a href="welcome" class="logo d-flex align-items-center">
                <i class="fa fa-hospital" style="font-size: xxx-large; margin: 0px 5px 0px 15px;"></i>
                <span class="d-none d-lg-block">ITKlinik</span>
            </a>
        </div>
        <nav class="header-nav ms-auto">
            <ul class="d-flex align-items-center">
                <li class="nav-item">
                    <a class="nav-link nav-icon search-bar-toggle " href="https://www.instagram.com">
                        <i class="bi bi-instagram"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-icon search-bar-toggle " href="https://www.facebook.com">
                        <i class="bi bi-facebook"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-icon search-bar-toggle " href="https://www.twitter.com">
                        <i class="bi bi-twitter"></i>
                    </a>
                </li>
            </ul>
        </nav>
    </header>
    
    <!-- ======= Hero Section ======= -->
    <section id="hero" class="d-flex align-items-center">
        <div class="container position-relative" data-aos="fade-up" data-aos-delay="500">
            <h1>Welcome to my ITKlinik</span></h1>
            <h2>Website dibuat untuk memenuhi tugas Pemrograman Web II</h2>
            <a href="login" class="btn-get-started scrollto">Login as Admin</a>
        </div>
    </section><!-- End Hero -->
     <div id="preloader"></div>

    <div class="footer">
        <p> &copy; 2023 | Tugas Kelompok TI.21.C2</p>
    </div>

    <script src="<?php echo base_url('js/main.js'); ?>"></script>

    <!-- Vendor JS Files -->
    <script src="assets/vendor/aos/aos.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>

    <!-- Template Main JS File -->
    <script src="assets/js/main.js"></script>

</body>

</html>