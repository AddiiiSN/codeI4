<?php echo $this->include('template/header'); ?>
<main id="main" class="main">
    <div class="judul">
        <h2 style="text-align: center; margin: 30px 0px 20px 0px;">Report</h2>
    </div>

    <table class="table table-hover table-borderless text-center">
        <thead class="table-active">
            <tr>
                <th class="">No</th>
                <th class="">Antrian</th>
                <th class="col-md-2">Nama</th>
                <th class="col-md-2">Usia</th>
                <th class="col-md-2">Jenis Kelamin</th>
                <th class="col-md-2">No. HP</th>
                <th class="col-md-2">Alamat</th>
                <th class="col-md-2">Jenis Pelayanan</th>
            </tr>
        </thead>
        <tbody class="table-bordered">
            <?php $i = 0; ?>
            <?php foreach ($report as $p) { ?>
            <tr>
                <td><?php echo ++$i; ?></td>
                <td><?php echo $p['idAntrian']; ?></td>
                <td><?php echo $p['nama']; ?></td>
                <td><?php echo $p['usia']; ?> Tahun</td>
                <td><?php echo $p['jenisKelamin']; ?></td>
                <td><?php echo $p['no.hp']; ?></td>
                <td><?php echo $p['alamat']; ?></td>
                <td><?php echo $p['jenisPelayanan']; ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
    </div>
</main>
<?php echo $this->include('template/footer'); ?>