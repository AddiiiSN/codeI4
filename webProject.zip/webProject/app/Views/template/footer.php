    <div class="footer">
        <p> &copy; 2023 | Tugas Kelompok TI.21.C2</p>
    </div>

    <script src="<?php echo base_url('js/main.js'); ?>"></script>

    </body>

    </html>