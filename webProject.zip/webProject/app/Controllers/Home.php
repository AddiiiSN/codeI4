<?php

namespace App\Controllers;

use App\Models\LoketModel;
use App\Models\PasienModel;
use App\Models\PelayananModel;
use App\Models\ReportModel;

class Home extends BaseController
{
    public function welcome()
    {
        return view('welcome');
    }

    public function index()
    {
        if (! $this->isLoggedIn()) {
            return redirect()->to('/');
        }
        
        $pelayananModel = new PelayananModel();
        $data['pelayanan'] = $pelayananModel->findAll();

        return view('pelayanan');
    }

    private function isLoggedIn() : bool
    {
        if (session()->get('logged_in')) {
            return true;
        }

        return false;
    }

    public function dataAntrian()
    {
        if (! $this->isLoggedIn()) {
            return redirect()->to('/');
        }        

        $pasienModel = new PasienModel();
        $data['datapasien'] = $pasienModel->findAll();

        return view('data-antrian', $data);
    }
    
    

    public function pelayanan()
    {
        if (! $this->isLoggedIn()) {
            return redirect()->to('/');
        }
        
        
        $pelayananModel = new PelayananModel();
        $data['pelayanan'] = $pelayananModel->findAll();

        return view('pelayanan', $data);
    }

    public function loket()
    {
        if (! $this->isLoggedIn()) {
            return redirect()->to('/');
        }
        
        
        $loketModel = new LoketModel();
        $data['loket'] = $loketModel->findAll();

        return view('loket', $data);
    }

    public function report()
    {
        if (! $this->isLoggedIn()) {
            return redirect()->to('/');
        }
        
        $reportModel = new ReportModel();
        $data['report'] = $reportModel->findAll();

        return view('report', $data);
    }
}