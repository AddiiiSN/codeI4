<?php namespace App\Controllers;

use \App\Models\PelayananModel;
use \App\Models\LoketModel;
use \App\Models\PasienModel;
use CodeIgniter\Exceptions\PageNotFoundException;

class NewsAdmin extends BaseController
{

    //--------------------------------------------------------------------------
    
    public function create()
    {
        // lakukan validasi
        $validation =  \Config\Services::validation();
        $isDataValid = $validation->withRequest($this->request)->run();

        // jika data valid, simpan ke database
        if($isDataValid){
            $pelayanan = new PelayananModel();
            $pelayanan->insert([
                "jenis" => $this->request->getPost('jenis'),
                "dokter" => $this->request->getPost('dokter'),
                "idDokter" => $this->request->getPost('idDokter'),
                "jamPraktek" => $this->request->getPost('jamPraktek')
            ]);
            return redirect('admin/pelayanan');
        }
		
        // tampilkan form create
        echo view('admin_create_pelayanan');
    }

    //--------------------------------------------------------------------------

    public function edit($id)
    {
        // ambil artikel yang akan diedit
        $news = new NewsModel();
        $data['news'] = $news->where('id', $id)->first();
        
        // lakukan validasi data artikel
        $validation =  \Config\Services::validation();
        $validation->setRules([
            'id' => 'required',
            'title' => 'required'
        ]);
        $isDataValid = $validation->withRequest($this->request)->run();
        // jika data vlid, maka simpan ke database
        if($isDataValid){
            $news->update($id, [
                "title" => $this->request->getPost('title'),
                "content" => $this->request->getPost('content'),
                "status" => $this->request->getPost('status')
            ]);
            return redirect('admin/news');
        }

        // tampilkan form edit
        echo view('admin_edit_news', $data);
    }

    //--------------------------------------------------------------------------

	public function delete($id){
        $news = new NewsModel();
        $news->delete($id);
        return redirect('admin/news');
    }
}